#!/bin/bash

# Change the colons of the wrfout to colons
rename :00:00 _00_00 wrfout*
