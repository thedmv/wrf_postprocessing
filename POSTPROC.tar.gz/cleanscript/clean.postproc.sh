#!/bin/bash

rm *.d01.nc
rm *.d03.nc
rm *.R
rm *.r
rm -r app_parts*
rm *Rmd
rm *html
rm *.ncl
rm merge.py
rm mergeHRRR.py
rm ncMerge.sh
rm ncMergeHRRR.sh
rm postproc.*
rm tmpMerged.nc
rm tmpMerged_sub.nc
